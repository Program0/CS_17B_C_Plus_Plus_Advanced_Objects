#ifndef PIECE
#define PIECE

#include <QWidget>

class Piece:public QWidget{

};

#endif // PIECE

