# CHECKERS_CSC17B_48941
Checkers Group: CIS-17B-48941C++ Prgm: Advanced Objects
