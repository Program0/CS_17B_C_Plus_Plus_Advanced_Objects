/*
 * Marlo Zeroth
 * September 22, 2015
 * CSC17B
 * Assignment 2
 * This is the interface for the Abstract Class MyArrayAbstract
 * File: myarrayabstract.h
 */


#ifndef MYARRAYABSTRACT_H
#define MYARRAYABSTRACT_H

class MyArrayAbstract{
public:
    //pure virtual function
    virtual void fillArray()=0;
};

#endif // MYARRAYABSTRACT_H

